//
//  MenuStyle3Cell.swift
//  Material Design IOS
//
//  Created by Denis Tirta Prada on 7/12/17.
//  Copyright © 2017 Mediatechindo. All rights reserved.
//

import UIKit

class MenuStyle3Cell: UITableViewCell {
    
    @IBOutlet var nameCell: UILabel!
}
