//
//  ViewController.swift
//  Inspire
//
//  Created by UMANG LOTIYA on 14/09/1940 Saka.
//  Copyright © 1940 UMANG LOTIYA. All rights reserved.
//

import UIKit
import Firebase
import FirebaseDatabase
class Welcome: UIViewController {

    
    override func viewDidLoad() {
        super.viewDidLoad()
     
        // Do any additional setup after loading the view, typically from a nib.
    }


   
}


