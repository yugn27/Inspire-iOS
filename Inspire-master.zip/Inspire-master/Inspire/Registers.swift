//
//  Registers.swift
//  Inspire
//
//  Created by UMANG LOTIYA on 14/09/1940 Saka.
//  Copyright © 1940 UMANG LOTIYA. All rights reserved.
//

import UIKit

class Registers: UIViewController {

    
    @IBOutlet weak var id: UITextField!
    @IBOutlet weak var department: UITextField!
    
    @IBOutlet weak var name: UITextField!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
